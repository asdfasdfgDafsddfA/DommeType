DommeType - batch femdom captions
=================================

DommeType burns femdom caption text onto a folder of images, using an AI model
you choose. Point it at your pictures, type what the captions should be about,
tweak the look, and it writes captioned copies at full resolution.

This folder contains:

  DommeType.exe    the whole app, in one file
  README.txt       this file

Nothing else is needed. There is no installer and no set-up.


1. RUN IT
---------

Windows
    Double-click DommeType.exe.

Linux / macOS / BSD
    Run the same exe with Wine:

        wine DommeType.exe

    (Install Wine first: "apt install wine" / "dnf install wine" /
     "pacman -S wine", or on macOS:
     "brew install --cask --no-quarantine wine-stable".)

The app opens in its own window. Close the window to quit.

KEEP THE EXE SOMEWHERE YOU CAN WRITE TO - your Desktop, Documents, a USB stick,
anywhere like that. The app saves your settings in "config.json" next to the
exe, so it needs a folder it is allowed to write in. Do not put it in
Program Files.

FIRST RUN
    Windows may say "Windows protected your PC", because the file is not
    code-signed. Click "More info", then "Run anyway". Antivirus tools also
    sometimes flag single-file apps like this on the first run.

    The very first launch takes a second or two longer while the app unpacks
    itself. After that it starts instantly.


2. POINT IT AT A MODEL
----------------------

The app does not include an AI model - it talks to one you provide. In the
"Model backend" section of the Setup tab, pick a provider, then press Connect:

    LM Studio    http://localhost:1234/v1     free, runs on your own PC
    Ollama       http://localhost:11434/v1    free, runs on your own PC
    Mistral      https://api.mistral.ai/v1    needs an API key
    Grok (xAI)   https://api.x.ai/v1          needs an API key

  * LM Studio: load a model first (a vision build such as Qwen2.5-VL, Gemma-3
    or LLaVA lets the captions actually look at each photo), then start the
    server: Developer menu -> Start Server.

  * Ollama: run "ollama serve" and pull a model first, for example
    "ollama pull llama3.1" - or a vision model: "ollama pull llava".

Nothing is sent anywhere except the provider you choose.


3. USE IT
---------

The window is split in two: preview on the left, controls on the right. The
tabs down the right are Setup, Prompt, Scenes and Look, and you work through
them in that order.

  1. SETUP -> Folders: Browse to your input folder, or drag images (or a whole
     folder) onto the picture. Leave the output folder empty and captioned
     copies land in <input>/captioned.

  2. SETUP -> Model backend: pick your provider, press Connect, choose a model,
     then Test connection.

  3. PROMPT: type a few words for Topic/kinks, e.g. "chastity slave, denial".
     Slide Tone left for soft and affectionate, right for cruel and mocking.
     The optional dials, names and scenario add flavour - leave them alone and
     they add nothing. If captions come back empty, raise Max tokens.

  4. SCENES (optional): switch on any of the 17 scene cards the batch is about.
     A card you leave untouched adds nothing at all to the prompt.

  5. LOOK: pick a font and colours. Click a colour swatch to set the text
     colour, shift-click for the outline, alt-click for the plate behind it.
     On the picture itself, drag the caption to move it and drag the pink
     handles to resize its box.

  6. Press "Generate captions for all" under the picture. When it finishes,
     step through the images with the arrow keys and edit any caption in the
     text box. Then press "Export captioned batch" to burn the text onto
     full-size images in the output folder.

Handy keys
    Ctrl+Z   undo the last caption change
    Ctrl+B   hide/show the control panel
    + - 0    zoom in, zoom out, fit
    <- ->    previous / next image

"Review all" opens a grid of every image with its caption already burned in;
click any tile to jump straight to it and fix it.


4. WHERE YOUR FILES GO
----------------------

    config.json      your settings - next to the exe. Delete it to reset
                     everything back to defaults.
    dommetype.log    a small startup log - next to the exe.
    output folder    your captioned images, plus a captions.json you can
                     re-use later.

The app is portable: move the exe anywhere and your settings come with it.


A NOTE ON THE WINDOW
--------------------

The window is drawn with Microsoft's Edge WebView2 runtime, which is part of
Windows 10 and Windows 11. On a machine where it is missing - or under Wine -
the app will say so and open its interface in your usual browser instead, so
you are never left stuck.


VERIFYING THE DOWNLOAD (optional)
---------------------------------

If you want to check the file arrived intact, open a terminal in this folder
and run:

    Windows:  certutil -hashfile DommeType.exe SHA256
    macOS:    shasum -a 256 DommeType.exe
    Linux:    sha256sum DommeType.exe

The result should be:

    9e0bf133bfe8a298cf80ae0e9798ef9cf5de988f48a8d5352b7d1676c6a973ee
